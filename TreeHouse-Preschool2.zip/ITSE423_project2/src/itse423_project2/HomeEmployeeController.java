package itse423_project2;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.ImageCursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class HomeEmployeeController implements Initializable {
    @FXML
    private Label nameviwe;

    @FXML
    private Accordion base;

    @FXML
    private Button userinfo,addstudent, editstudent, searchstudent,addcourse, showcourse, addclass, showclass, showschedule,editUserInfo;

    @FXML
    private Pane content;
    @FXML
    private TextField name, email,adress;
    
    public void start() {
        List <DBinfo> list=DBcon.getUserInfo(1); // from database
        for(DBinfo a:list){
            nameviwe.setText(a.getUfirstname()+" "+a.getUlastname());
            name.setText(a.getUfirstname()+" "+a.getUsecoundname()+" "+a.getUlastname());
            adress.setText(a.getUaddress());}
        }
    
    @FXML
    void clickBottonexit(ActionEvent event) throws SQLException, IOException{
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
        Parent root = FXMLLoader.load(getClass().getResource("LogInForm.fxml"));
        Scene scene = new Scene(root);
        Image image = new Image(this.getClass().getResourceAsStream("pin.png"));
        scene.setCursor(new ImageCursor(image));
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void studentManager(ActionEvent event)throws SQLException, IOException{
        
        AnchorPane newLoadedPane;
        Button tempButton = (Button)event.getSource();
        Stage stage;
        switch(tempButton.getId()){
            case"addstudent":
                newLoadedPane =  FXMLLoader.load(getClass().getResource("addstudent.fxml")); 
                content.getChildren().clear();
                content.getChildren().add(newLoadedPane);
                base=(Accordion)newLoadedPane.getChildren().get(0);
                base.setExpandedPane(base.getPanes().get(0));
                stage = (Stage) content.getScene().getWindow();
                stage.sizeToScene();
                break; 
            case"editstudent":
                newLoadedPane =  FXMLLoader.load(getClass().getResource("editstudent.fxml"));
                content.getChildren().clear();
                content.getChildren().add(newLoadedPane);
                base=(Accordion)newLoadedPane.getChildren().get(0);
                base.setExpandedPane(base.getPanes().get(0));
                stage = (Stage) content.getScene().getWindow();
                stage.sizeToScene();
                break;
            case"searchstudent":
                newLoadedPane =  FXMLLoader.load(getClass().getResource("searchstudent.fxml"));
                content.getChildren().clear();
                content.getChildren().add(newLoadedPane);
                base=(Accordion)newLoadedPane.getChildren().get(0);
                base.setExpandedPane(base.getPanes().get(0));
                stage = (Stage) content.getScene().getWindow();
                stage.sizeToScene();
                break;
        }
    }
    
    @FXML
    private void userinfo(ActionEvent event) throws IOException{
        List <DBinfo> list=DBcon.getUserInfo(1); // from database
        for(DBinfo a:list){
            name.setText(a.getUfirstname()+" "+a.getUsecoundname()+" "+a.getUlastname());
            adress.setText(a.getUaddress());
        }
    }
    
    @FXML
    private void coursesManager(ActionEvent event)throws SQLException, IOException{
        AnchorPane newLoadedPane;
        Button tempButton = (Button)event.getSource();
        Stage stage;
        switch(tempButton.getId()){
            case"addcourse":
                newLoadedPane =  FXMLLoader.load(getClass().getResource("addcourse.fxml")); 
                content.getChildren().clear();
                content.getChildren().add(newLoadedPane);
                base=(Accordion)newLoadedPane.getChildren().get(0);
                base.setExpandedPane(base.getPanes().get(0));
                stage = (Stage) content.getScene().getWindow();
                stage.sizeToScene();
                break; 
            case"showcourse":
                newLoadedPane =  FXMLLoader.load(getClass().getResource("showcourse.fxml"));
                content.getChildren().clear();
                content.getChildren().add(newLoadedPane);
                base=(Accordion)newLoadedPane.getChildren().get(0);
                base.setExpandedPane(base.getPanes().get(0));
                stage = (Stage) content.getScene().getWindow();
                stage.sizeToScene();
                break;
        }
        
    }
    
    @FXML
    private void classesManager(ActionEvent event)throws SQLException, IOException{
        AnchorPane newLoadedPane;
        Button tempButton = (Button)event.getSource();
        Stage stage;
        switch(tempButton.getId()){
            case"addclass":
                newLoadedPane =  FXMLLoader.load(getClass().getResource("addclass.fxml")); 
                content.getChildren().clear();
                content.getChildren().add(newLoadedPane);
                base=(Accordion)newLoadedPane.getChildren().get(0);
                base.setExpandedPane(base.getPanes().get(0));
                stage = (Stage) content.getScene().getWindow();
                stage.sizeToScene();
                break; 
            case"showclass":
                newLoadedPane =  FXMLLoader.load(getClass().getResource("showclass.fxml"));
                content.getChildren().clear();
                content.getChildren().add(newLoadedPane);
                base=(Accordion)newLoadedPane.getChildren().get(0);
                base.setExpandedPane(base.getPanes().get(0));
                stage = (Stage) content.getScene().getWindow();
                stage.sizeToScene();
                break;
        }
    }
    
    @FXML
    private void showSchrdule(ActionEvent event)throws SQLException, IOException{
        AnchorPane newLoadedPane;
        Button tempButton = (Button)event.getSource();
        Stage stage;
        newLoadedPane =  FXMLLoader.load(getClass().getResource("showSchrdule.fxml")); 
        content.getChildren().clear();
        content.getChildren().add(newLoadedPane);
        base=(Accordion)newLoadedPane.getChildren().get(0);
        base.setExpandedPane(base.getPanes().get(0));
        stage = (Stage) content.getScene().getWindow();
        stage.sizeToScene();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        start();// method form load user info is scene 
    }
}